package net.shoreline.client.impl.async;

import lombok.RequiredArgsConstructor;
import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@RequiredArgsConstructor
public abstract class AsyncBlockScanner
{
    protected final int radius;

    private final ConcurrentMap<BlockPos, BlockState> asyncSphere = new ConcurrentHashMap<>();

    public void createSphere(ClientWorld world, BlockPos center)
    {
        for (int dx = -radius; dx <= radius; ++dx)
        {
            for (int dy = -radius; dy <= radius; ++dy)
            {
                for (int dz = -radius; dz <= radius; ++dz)
                {
                    BlockPos pos = BlockPos.ofFloored(center.getX() + dx,
                            center.getY() + dy,
                            center.getZ() + dz);

                    asyncSphere.put(pos, world.getBlockState(pos));
                }
            }
        }
    }

    public void scanSphere()
    {
        for (Map.Entry<BlockPos, BlockState> entry : asyncSphere.entrySet())
        {
            visit(entry.getKey(), entry.getValue());
        }
    }

    protected BlockState getBlockState(BlockPos blockPos)
    {
        return asyncSphere.get(blockPos);
    }

    protected abstract void visit(BlockPos pos, BlockState state);
}
